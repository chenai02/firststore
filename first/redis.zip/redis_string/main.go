package main

import (
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"log"
	"runtime"
	"sync"
	"time"
)
var(
	Ctx = context.Background()
	Redisdb *redis.Client
	Wg sync.WaitGroup
)

// Redis初始化
func Redis_init(){
	Redisdb = redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "", // no password set
		DB:       0,  // use default DB
	})
}
func Redis_String() {
	log.Println("测试set")
	//kv读写 当过期时间为0时，则表明没有过期时间
	for i := int64(0); i < 10000 ; i++{
		Wg.Add(1)
		go func(i int64) {
			err := Redisdb.Set(Ctx, string(i), "", 100*time.Second).Err()
			if err != nil {
				log.Println("redis add failed,err:%v", err)
				return
			}
			Wg.Done()
		}(i)
	}
}
func main() {
	cpuNum := runtime.NumCPU()
	fmt.Println("cpuNum=", cpuNum)
	//可以自己设置使用多个cpu
	runtime.GOMAXPROCS(cpuNum - 1)
	Redis_init()
	t1 := time.Now()
	Redis_String()
	t2 := time.Now()
	fmt.Println(t2.Sub(t1))
	Wg.Wait()
}
