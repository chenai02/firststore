package main

import (
	"context"
	"log"
	"time"
	"github.com/go-redis/redis/v8"
	"sync"
)
var ctx = context.Background()
var redisdb *redis.Client
var wg sync.WaitGroup
// Redis初始化
func Redis_init(){
	redisdb = redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "", // no password set
		DB:       0,  // use default DB
	})
}

func Redis_String(){
	log.Println("ExampleClient_String")
	//kv读写 当过期时间为0时，则表明没有过期时间
	err := redisdb.Set(ctx, "key", "value", 0).Err()
	log.Println(err)

	//获取过期时间
	tm, err := redisdb.TTL(ctx, "key").Result()
	log.Println(tm)
	time.Sleep(2*time.Second)
	val, err := redisdb.Get(ctx, "key").Result()
	if err != nil {
		log.Println("err:", err)
	}else{
		log.Println(val)
	}

}
func Redis_Hash(){

}
func main() {
	Redis_init()
	Redis_String()


}